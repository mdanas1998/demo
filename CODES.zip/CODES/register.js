import React, { useState, useContext } from "react";
import { 
    Button, 
    Text,
    TextInput, 
    TouchableOpacity,
    View,
    StyleSheet, 
} from "react-native";
import { AuthContext } from "../context/AuthContext";
                 
const RegisterScreen = ({navigation}) => {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [mobileNumber, setMobileNumber] = useState("");
    const [email, setEmail] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const val = useContext(AuthContext);

    const handleRegister = () => {
        // Check if email and password are valid
        // Log user in if they are
    };

    return (
        
        <View style={styles.container}>
            <View style={styles.wrapper}>
                <Text>{val}</Text>
                <TextInput 
                    style={styles.input} 
                    value={firstName}
                    placeholder="Enter First name" 
                    onChangeText={text => setFirstName(text)}
                />

                <TextInput 
                    style={styles.input} 
                    value={lastName}
                    placeholder="Enter Last name" 
                    onChangeText={text => setLastName(text)}
                />

                <TextInput 
                    style={styles.input} 
                    value={mobileNumber}
                    placeholder="Enter Mobile number" 
                    onChangeText={text => setMobileNumber(text)}
                />

                <TextInput 
                    style={styles.input} 
                    value={email}
                    placeholder="Enter email" 
                    onChangeText={text => setEmail(text)}
                />
                
                <TextInput
                    style={styles.input} 
                    value={newPassword}
                    placeholder="Enter New password"
                    onChangeText={text => setNewPassword(text)}
                    secureTextEntry
                />

                <TextInput
                    style={styles.input} 
                    value={confirmPassword}
                    placeholder="Confirm password"
                    onChangeText={text => setConfirmPassword(text)}
                    secureTextEntry
                />

                <Button title="Register" onPress={handleRegister} />

                <View style={{flexDirection: 'row', marginTop: 20}}>
                    <Text>Already have an account? </Text>
                    <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                        <Text style={styles.link}>Login</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
};

const styles  = StyleSheet.create ({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    wrapper: {
        width: '80%',
    },
    input: {
        marginBottom: 12,
        borderWidth: 1,
        borderColor: '#bbb',
        borderRadius: 5,
        paddingHorizontal: 14,
    },
    link: {
        color: 'blue',
    }
});

export default RegisterScreen;