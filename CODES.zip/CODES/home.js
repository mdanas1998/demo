import React from "react";
import {Text, View} from "react-native";                  

const HomeScreen = () => {
    return (
        <View>
            <Text>HomeScreen</Text>
            </View>
    );
};

export default HomeScreen;